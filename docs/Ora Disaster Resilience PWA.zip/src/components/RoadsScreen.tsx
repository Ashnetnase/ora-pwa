import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Route, Search, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

interface RoadClosure {
  id: string;
  road: string;
  location: string;
  reason: string;
  status: 'active' | 'partial' | 'resolved';
  severity: 'low' | 'medium' | 'high';
  reportedAt: string;
  estimatedClearance?: string;
  detour?: string;
}

const mockRoadClosures: RoadClosure[] = [
  {
    id: '1',
    road: 'State Highway 1',
    location: 'Auckland Harbour Bridge',
    reason: 'High winds - lane restrictions in place',
    status: 'partial',
    severity: 'medium',
    reportedAt: '2025-01-18T10:30:00Z',
    estimatedClearance: '6 hours',
    detour: 'Use Western Ring Route via SH18/SH16'
  },
  {
    id: '2',
    road: 'State Highway 6',
    location: 'Arthur\'s Pass',
    reason: 'Rockfall blocking southbound lane',
    status: 'active',
    severity: 'high',
    reportedAt: '2025-01-18T08:15:00Z',
    estimatedClearance: 'Unknown',
    detour: 'Use Lewis Pass Route via SH7'
  },
  {
    id: '3',
    road: 'Queen Street',
    location: 'Auckland CBD',
    reason: 'Emergency maintenance',
    status: 'resolved',
    severity: 'low',
    reportedAt: '2025-01-18T06:00:00Z',
    estimatedClearance: 'Cleared'
  },
  {
    id: '4',
    road: 'State Highway 2',
    location: 'Rimutaka Hill Road',
    reason: 'Ice warning - drive with caution',
    status: 'partial',
    severity: 'medium',
    reportedAt: '2025-01-18T05:45:00Z',
    estimatedClearance: '3 hours',
    detour: 'Consider alternative routes'
  },
  {
    id: '5',
    road: 'Christchurch Northern Motorway',
    location: 'Waimakariri Bridge',
    reason: 'Vehicle breakdown - left lane closed',
    status: 'active',
    severity: 'low',
    reportedAt: '2025-01-18T11:20:00Z',
    estimatedClearance: '30 minutes'
  }
];

export function RoadsScreen() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-ora-red text-white';
      case 'partial': return 'bg-ora-orange text-white';
      case 'resolved': return 'bg-ora-green text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'border-l-ora-red';
      case 'medium': return 'border-l-ora-orange';
      case 'low': return 'border-l-ora-green';
      default: return 'border-l-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <AlertTriangle className="w-4 h-4" />;
      case 'partial': return <Clock className="w-4 h-4" />;
      case 'resolved': return <CheckCircle className="w-4 h-4" />;
      default: return <Route className="w-4 h-4" />;
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)}h ago`;
    return `${Math.floor(diffMinutes / 1440)}d ago`;
  };

  const filteredClosures = mockRoadClosures.filter(closure => {
    const matchesSearch = closure.road.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         closure.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || closure.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusFilters = [
    { value: 'all', label: 'All', count: mockRoadClosures.length },
    { value: 'active', label: 'Active', count: mockRoadClosures.filter(c => c.status === 'active').length },
    { value: 'partial', label: 'Partial', count: mockRoadClosures.filter(c => c.status === 'partial').length },
    { value: 'resolved', label: 'Resolved', count: mockRoadClosures.filter(c => c.status === 'resolved').length }
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 bg-white border-b">
        <h1 className="mb-4">Road Conditions</h1>
        
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search roads or locations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 rounded-xl"
          />
        </div>

        {/* Status Filters */}
        <div className="flex gap-2 overflow-x-auto">
          {statusFilters.map((filter) => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter(filter.value)}
              className={`flex-shrink-0 rounded-xl ${
                statusFilter === filter.value 
                  ? 'bg-ora-blue text-white' 
                  : 'border-gray-300'
              }`}
            >
              {filter.label} ({filter.count})
            </Button>
          ))}
        </div>
      </div>

      {/* Road Closures List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredClosures.length === 0 ? (
          <div className="text-center py-8">
            <Route className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No road closures found</p>
          </div>
        ) : (
          filteredClosures.map((closure) => (
            <Card key={closure.id} className={`p-4 rounded-xl border-l-4 ${getSeverityColor(closure.severity)}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge className={`rounded-xl ${getStatusColor(closure.status)} flex items-center gap-1`}>
                      {getStatusIcon(closure.status)}
                      {closure.status.toUpperCase()}
                    </Badge>
                    <span className="text-xs text-gray-500">{formatTime(closure.reportedAt)}</span>
                  </div>
                  <h3 className="mb-1">{closure.road}</h3>
                  <p className="text-sm text-gray-600 mb-2">{closure.location}</p>
                </div>
              </div>

              <p className="text-sm mb-3">{closure.reason}</p>

              <div className="space-y-2 text-sm">
                {closure.estimatedClearance && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">
                      Estimated clearance: <span className="font-medium">{closure.estimatedClearance}</span>
                    </span>
                  </div>
                )}
                
                {closure.detour && (
                  <div className="bg-blue-50 p-3 rounded-lg border-l-4 border-ora-blue">
                    <p className="text-sm">
                      <span className="font-medium text-ora-blue">Detour: </span>
                      {closure.detour}
                    </p>
                  </div>
                )}
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}