import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { 
  Shield, 
  Home, 
  Car, 
  Briefcase, 
  Heart, 
  AlertTriangle, 
  ChevronDown, 
  ChevronRight,
  WifiOff,
  Download
} from 'lucide-react';

interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

interface SafetyChecklist {
  id: string;
  title: string;
  icon: React.ReactNode;
  description: string;
  category: string;
  items: ChecklistItem[];
}

export function InfoScreen() {
  const [isOffline] = useState(false); // This would typically check actual network status
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const [checklists, setChecklists] = useState<SafetyChecklist[]>([
    {
      id: 'home',
      title: 'Home Emergency Kit',
      icon: <Home className="w-5 h-5" />,
      description: 'Essential supplies for your household emergency kit',
      category: 'Preparation',
      items: [
        { id: '1', text: 'Water (3 litres per person per day for 3 days)', completed: false },
        { id: '2', text: 'Non-perishable food for 3 days', completed: false },
        { id: '3', text: 'Battery-powered radio', completed: false },
        { id: '4', text: 'Flashlight and extra batteries', completed: false },
        { id: '5', text: 'First aid kit', completed: false },
        { id: '6', text: 'Medications (7-day supply)', completed: false },
        { id: '7', text: 'Cash in small bills', completed: false },
        { id: '8', text: 'Important documents in waterproof container', completed: false }
      ]
    },
    {
      id: 'workplace',
      title: 'Workplace Safety',
      icon: <Briefcase className="w-5 h-5" />,
      description: 'Know your workplace emergency procedures',
      category: 'Preparation',
      items: [
        { id: '1', text: 'Know evacuation routes from your workplace', completed: false },
        { id: '2', text: 'Identify safe spots under desks or tables', completed: false },
        { id: '3', text: 'Keep emergency kit in desk drawer', completed: false },
        { id: '4', text: 'Know location of first aid stations', completed: false },
        { id: '5', text: 'Participate in regular emergency drills', completed: false }
      ]
    },
    {
      id: 'earthquake',
      title: 'During an Earthquake',
      icon: <AlertTriangle className="w-5 h-5" />,
      description: 'What to do when the ground starts shaking',
      category: 'Response',
      items: [
        { id: '1', text: 'Drop to hands and knees immediately', completed: false },
        { id: '2', text: 'Take cover under a sturdy desk or table', completed: false },
        { id: '3', text: 'Hold on to your shelter and protect your head', completed: false },
        { id: '4', text: 'Stay where you are until shaking stops', completed: false },
        { id: '5', text: 'If outdoors, move away from buildings and trees', completed: false },
        { id: '6', text: 'If driving, pull over safely and stop', completed: false }
      ]
    },
    {
      id: 'first-aid',
      title: 'Basic First Aid',
      icon: <Heart className="w-5 h-5" />,
      description: 'Essential first aid knowledge for emergencies',
      category: 'Response',
      items: [
        { id: '1', text: 'Check for responsiveness and breathing', completed: false },
        { id: '2', text: 'Call 111 for emergency services', completed: false },
        { id: '3', text: 'Control bleeding with direct pressure', completed: false },
        { id: '4', text: 'Keep injured person warm and comfortable', completed: false },
        { id: '5', text: 'Do not move person with suspected spinal injury', completed: false }
      ]
    },
    {
      id: 'vehicle',
      title: 'Vehicle Emergency Kit',
      icon: <Car className="w-5 h-5" />,
      description: 'Keep these items in your vehicle at all times',
      category: 'Preparation',
      items: [
        { id: '1', text: 'Jumper cables', completed: false },
        { id: '2', text: 'Spare tire (properly inflated)', completed: false },
        { id: '3', text: 'Emergency flares or reflectors', completed: false },
        { id: '4', text: 'Multi-tool or knife', completed: false },
        { id: '5', text: 'Ice scraper and snow brush', completed: false },
        { id: '6', text: 'Emergency blanket', completed: false },
        { id: '7', text: 'Water and snacks', completed: false }
      ]
    }
  ]);

  const toggleCard = (cardId: string) => {
    const newExpanded = new Set(expandedCards);
    if (newExpanded.has(cardId)) {
      newExpanded.delete(cardId);
    } else {
      newExpanded.add(cardId);
    }
    setExpandedCards(newExpanded);
  };

  const toggleItem = (checklistId: string, itemId: string) => {
    setChecklists(prev => prev.map(checklist => {
      if (checklist.id === checklistId) {
        return {
          ...checklist,
          items: checklist.items.map(item => 
            item.id === itemId ? { ...item, completed: !item.completed } : item
          )
        };
      }
      return checklist;
    }));
  };

  const getCompletionPercentage = (items: ChecklistItem[]) => {
    const completed = items.filter(item => item.completed).length;
    return Math.round((completed / items.length) * 100);
  };

  const preparationChecklists = checklists.filter(c => c.category === 'Preparation');
  const responseChecklists = checklists.filter(c => c.category === 'Response');

  return (
    <div className="flex flex-col h-full">
      {/* Offline Banner */}
      {isOffline && (
        <div className="bg-gray-800 text-white p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <WifiOff className="w-4 h-4" />
            <span className="text-sm">You're offline - content available locally</span>
          </div>
          <Button size="sm" variant="outline" className="text-white border-white hover:bg-white hover:text-gray-800">
            <Download className="w-4 h-4 mr-1" />
            Update
          </Button>
        </div>
      )}

      {/* Header */}
      <div className="p-4 bg-white border-b">
        <h1 className="mb-2">Emergency Information</h1>
        <p className="text-gray-600">Safety checklists and emergency procedures</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          
          {/* Preparation Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-ora-blue" />
              <h2 className="text-ora-blue">Preparation</h2>
            </div>
            <div className="space-y-3">
              {preparationChecklists.map((checklist) => (
                <Card key={checklist.id} className="rounded-xl overflow-hidden">
                  <Collapsible
                    open={expandedCards.has(checklist.id)}
                    onOpenChange={() => toggleCard(checklist.id)}
                  >
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full p-4 h-auto justify-between hover:bg-gray-50"
                      >
                        <div className="flex items-start gap-3 text-left">
                          <div className="text-ora-blue mt-1">
                            {checklist.icon}
                          </div>
                          <div className="flex-1">
                            <h3 className="mb-1">{checklist.title}</h3>
                            <p className="text-sm text-gray-600 mb-2">{checklist.description}</p>
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-ora-green h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${getCompletionPercentage(checklist.items)}%` }}
                                />
                              </div>
                              <span className="text-xs text-gray-500">
                                {getCompletionPercentage(checklist.items)}%
                              </span>
                            </div>
                          </div>
                        </div>
                        {expandedCards.has(checklist.id) ? (
                          <ChevronDown className="w-4 h-4 text-gray-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-4 pb-4">
                      <div className="space-y-2">
                        {checklist.items.map((item) => (
                          <label
                            key={item.id}
                            className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={item.completed}
                              onChange={() => toggleItem(checklist.id, item.id)}
                              className="mt-1 w-4 h-4 text-ora-green border-2 border-gray-300 rounded focus:ring-ora-green"
                            />
                            <span className={`text-sm ${
                              item.completed ? 'line-through text-gray-500' : 'text-gray-700'
                            }`}>
                              {item.text}
                            </span>
                          </label>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                </Card>
              ))}
            </div>
          </div>

          {/* Response Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-ora-red" />
              <h2 className="text-ora-red">Emergency Response</h2>
            </div>
            <div className="space-y-3">
              {responseChecklists.map((checklist) => (
                <Card key={checklist.id} className="rounded-xl overflow-hidden">
                  <Collapsible
                    open={expandedCards.has(checklist.id)}
                    onOpenChange={() => toggleCard(checklist.id)}
                  >
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full p-4 h-auto justify-between hover:bg-gray-50"
                      >
                        <div className="flex items-start gap-3 text-left">
                          <div className="text-ora-red mt-1">
                            {checklist.icon}
                          </div>
                          <div className="flex-1">
                            <h3 className="mb-1">{checklist.title}</h3>
                            <p className="text-sm text-gray-600">{checklist.description}</p>
                          </div>
                        </div>
                        {expandedCards.has(checklist.id) ? (
                          <ChevronDown className="w-4 h-4 text-gray-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-4 pb-4">
                      <div className="space-y-2">
                        {checklist.items.map((item, index) => (
                          <div
                            key={item.id}
                            className="flex items-start gap-3 p-2 rounded-lg"
                          >
                            <Badge 
                              variant="outline" 
                              className="min-w-[24px] h-6 rounded-full flex items-center justify-center text-xs font-medium"
                            >
                              {index + 1}
                            </Badge>
                            <span className="text-sm text-gray-700 flex-1">
                              {item.text}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                </Card>
              ))}
            </div>
          </div>

          {/* Emergency Contacts */}
          <Card className="p-4 rounded-xl bg-red-50 border-red-200">
            <h3 className="text-red-800 mb-3">Emergency Contacts</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-red-700">Emergency Services:</span>
                <span className="font-medium text-red-800">111</span>
              </div>
              <div className="flex justify-between">
                <span className="text-red-700">Civil Defence:</span>
                <span className="font-medium text-red-800">0800 GET READY</span>
              </div>
              <div className="flex justify-between">
                <span className="text-red-700">Healthline:</span>
                <span className="font-medium text-red-800">0800 611 116</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}