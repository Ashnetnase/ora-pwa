import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Camera, MapPin, CheckCircle, Upload } from 'lucide-react';
import { Badge } from './ui/badge';

export function ReportScreen() {
  const [formData, setFormData] = useState({
    category: '',
    description: '',
    location: '',
    photo: null as File | null
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const hazardCategories = [
    { value: 'earthquake', label: 'Earthquake', color: 'bg-ora-red' },
    { value: 'flooding', label: 'Flooding', color: 'bg-ora-blue' },
    { value: 'road-closure', label: 'Road Closure', color: 'bg-ora-orange' },
    { value: 'fire', label: 'Fire', color: 'bg-ora-red' },
    { value: 'storm-damage', label: 'Storm Damage', color: 'bg-gray-500' },
    { value: 'other', label: 'Other', color: 'bg-gray-400' }
  ];

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFormData(prev => ({ ...prev, photo: file }));
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setFormData(prev => ({ 
            ...prev, 
            location: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}` 
          }));
        },
        () => {
          // Fallback to mock location for demo
          setFormData(prev => ({ 
            ...prev, 
            location: '-41.2865, 174.7762 (Wellington)' 
          }));
        }
      );
    } else {
      setFormData(prev => ({ 
        ...prev, 
        location: '-41.2865, 174.7762 (Wellington)' 
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        category: '',
        description: '',
        location: '',
        photo: null
      });
    }, 3000);
  };

  if (isSubmitted) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="p-8 text-center rounded-xl max-w-sm w-full">
          <div className="w-16 h-16 bg-ora-green rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <h2 className="mb-2">Report Submitted</h2>
          <p className="text-gray-600 mb-4">
            Thank you for your report. Emergency services have been notified and will respond accordingly.
          </p>
          <Badge className="bg-ora-green text-white rounded-xl">
            Report ID: #ORA-{Date.now().toString().slice(-6)}
          </Badge>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      <div className="max-w-lg mx-auto">
        <div className="mb-6">
          <h1 className="mb-2">Report a Hazard</h1>
          <p className="text-gray-600">
            Help keep your community safe by reporting hazards and emergencies.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Category Selection */}
          <Card className="p-4 rounded-xl">
            <Label htmlFor="category" className="block mb-3">Hazard Category</Label>
            <Select onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
              <SelectTrigger className="rounded-xl">
                <SelectValue placeholder="Select hazard type" />
              </SelectTrigger>
              <SelectContent>
                {hazardCategories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${category.color}`} />
                      {category.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Card>

          {/* Description */}
          <Card className="p-4 rounded-xl">
            <Label htmlFor="description" className="block mb-3">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe the hazard in detail..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="rounded-xl min-h-[100px]"
              required
            />
          </Card>

          {/* Photo Upload */}
          <Card className="p-4 rounded-xl">
            <Label className="block mb-3">Photo (Optional)</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center">
              {formData.photo ? (
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-ora-green rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-sm text-gray-600">{formData.photo.name}</p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setFormData(prev => ({ ...prev, photo: null }))}
                    className="rounded-xl"
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Camera className="w-12 h-12 text-gray-400 mx-auto" />
                  <p className="text-sm text-gray-600">Add a photo to help emergency services</p>
                  <label htmlFor="photo-upload">
                    <Button type="button" variant="outline" className="rounded-xl cursor-pointer">
                      <Upload className="w-4 h-4 mr-2" />
                      Choose Photo
                    </Button>
                  </label>
                  <input
                    id="photo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>
              )}
            </div>
          </Card>

          {/* Location */}
          <Card className="p-4 rounded-xl">
            <Label htmlFor="location" className="block mb-3">Location</Label>
            <div className="flex gap-2">
              <Input
                id="location"
                placeholder="Enter location or coordinates"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="rounded-xl flex-1"
                required
              />
              <Button
                type="button"
                variant="outline"
                onClick={getCurrentLocation}
                className="rounded-xl px-3"
              >
                <MapPin className="w-4 h-4" />
              </Button>
            </div>
          </Card>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-ora-blue hover:bg-ora-blue/90 text-white rounded-xl py-3"
            disabled={!formData.category || !formData.description || !formData.location}
          >
            Submit Report
          </Button>
        </form>
      </div>
    </div>
  );
}