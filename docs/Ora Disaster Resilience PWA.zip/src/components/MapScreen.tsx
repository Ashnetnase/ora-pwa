import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MapPin, AlertTriangle, Route, Users } from 'lucide-react';

interface MapMarker {
  id: string;
  type: 'earthquake' | 'road' | 'community';
  lat: number;
  lng: number;
  title: string;
  description: string;
  severity?: 'low' | 'medium' | 'high';
  status?: 'active' | 'resolved';
}

const mockMarkers: MapMarker[] = [
  {
    id: '1',
    type: 'earthquake',
    lat: -41.2865,
    lng: 174.7762,
    title: 'Wellington Earthquake',
    description: 'Magnitude 4.2 earthquake reported',
    severity: 'medium'
  },
  {
    id: '2',
    type: 'road',
    lat: -36.8485,
    lng: 174.7633,
    title: 'SH1 Closure',
    description: 'Auckland Harbour Bridge - lane closure due to high winds',
    status: 'active'
  },
  {
    id: '3',
    type: 'community',
    lat: -43.5321,
    lng: 172.6362,
    title: 'Christchurch Community Center',
    description: 'Emergency shelter available',
    status: 'active'
  },
  {
    id: '4',
    type: 'earthquake',
    lat: -45.8740,
    lng: 170.5036,
    title: 'Dunedin Tremor',
    description: 'Minor earthquake felt in central Dunedin',
    severity: 'low'
  }
];

const filterChips = [
  { id: 'all', label: 'All', color: 'bg-gray-100' },
  { id: 'earthquake', label: 'Earthquakes', color: 'bg-ora-red' },
  { id: 'road', label: 'Road Issues', color: 'bg-ora-orange' },
  { id: 'community', label: 'Community', color: 'bg-ora-green' }
];

export function MapScreen() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);

  const getMarkerIcon = (type: string) => {
    switch (type) {
      case 'earthquake': return <AlertTriangle className="w-4 h-4 text-white" />;
      case 'road': return <Route className="w-4 h-4 text-white" />;
      case 'community': return <Users className="w-4 h-4 text-white" />;
      default: return <MapPin className="w-4 h-4 text-white" />;
    }
  };

  const getMarkerColor = (type: string) => {
    switch (type) {
      case 'earthquake': return 'bg-ora-red';
      case 'road': return 'bg-ora-orange';
      case 'community': return 'bg-ora-green';
      default: return 'bg-gray-500';
    }
  };

  const filteredMarkers = activeFilter === 'all' 
    ? mockMarkers 
    : mockMarkers.filter(marker => marker.type === activeFilter);

  return (
    <div className="flex flex-col h-full">
      {/* Filter Chips */}
      <div className="p-4 bg-white border-b">
        <div className="flex gap-2 overflow-x-auto">
          {filterChips.map((chip) => (
            <Button
              key={chip.id}
              variant={activeFilter === chip.id ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveFilter(chip.id)}
              className={`flex-shrink-0 rounded-xl ${
                activeFilter === chip.id 
                  ? chip.id === 'all' ? 'bg-ora-blue text-white' : `${chip.color} text-white`
                  : 'border-gray-300'
              }`}
            >
              {chip.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative bg-gradient-to-br from-blue-50 to-green-50">
        {/* Simplified NZ Map Outline */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-64 h-80">
            {/* NZ Map SVG Outline */}
            <svg viewBox="0 0 200 300" className="w-full h-full opacity-20">
              <path
                d="M50 80 Q60 70 80 75 Q100 80 120 90 Q140 100 150 120 Q160 140 155 160 Q150 180 140 200 Q130 220 120 240 Q110 260 100 280 Q80 290 60 285 Q40 280 30 260 Q20 240 25 220 Q30 200 35 180 Q40 160 45 140 Q50 120 55 100 Z"
                fill="currentColor"
                className="text-gray-300"
              />
              <path
                d="M80 20 Q90 15 110 18 Q130 22 145 35 Q160 50 165 70 Q170 90 160 110 Q150 130 135 145 Q120 160 105 165 Q90 170 75 165 Q60 160 50 145 Q40 130 35 110 Q30 90 35 70 Q40 50 55 35 Q70 20 80 20 Z"
                fill="currentColor"
                className="text-gray-300"
              />
            </svg>

            {/* Map Markers */}
            {filteredMarkers.map((marker) => (
              <button
                key={marker.id}
                onClick={() => setSelectedMarker(marker)}
                className={`absolute w-8 h-8 rounded-full ${getMarkerColor(marker.type)} 
                  shadow-lg flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2 
                  hover:scale-110 transition-transform z-10`}
                style={{
                  left: `${((marker.lng + 180) / 360) * 100}%`,
                  top: `${((90 - marker.lat) / 180) * 100}%`
                }}
              >
                {getMarkerIcon(marker.type)}
              </button>
            ))}
          </div>
        </div>

        {/* Marker Details Popup */}
        {selectedMarker && (
          <div className="absolute bottom-4 left-4 right-4 z-20">
            <Card className="p-4 rounded-xl shadow-lg">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-6 h-6 rounded-full ${getMarkerColor(selectedMarker.type)} 
                      flex items-center justify-center`}>
                      {getMarkerIcon(selectedMarker.type)}
                    </div>
                    <h3 className="font-medium">{selectedMarker.title}</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{selectedMarker.description}</p>
                  <div className="flex gap-2">
                    {selectedMarker.severity && (
                      <Badge 
                        variant="secondary"
                        className={`rounded-xl ${
                          selectedMarker.severity === 'high' ? 'bg-red-100 text-red-800' :
                          selectedMarker.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}
                      >
                        {selectedMarker.severity} severity
                      </Badge>
                    )}
                    {selectedMarker.status && (
                      <Badge 
                        variant="secondary"
                        className={`rounded-xl ${
                          selectedMarker.status === 'active' ? 'bg-orange-100 text-orange-800' :
                          'bg-green-100 text-green-800'
                        }`}
                      >
                        {selectedMarker.status}
                      </Badge>
                    )}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedMarker(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}