import React, { useState } from 'react';
import { MapScreen } from './components/MapScreen';
import { ReportScreen } from './components/ReportScreen';
import { RoadsScreen } from './components/RoadsScreen';
import { InfoScreen } from './components/InfoScreen';
import { Map, Route, Plus, Info } from 'lucide-react';

type Screen = 'map' | 'roads' | 'report' | 'info';

const navigationItems = [
  { id: 'map' as Screen, label: 'Map', icon: Map },
  { id: 'roads' as Screen, label: 'Roads', icon: Route },
  { id: 'report' as Screen, label: 'Report', icon: Plus },
  { id: 'info' as Screen, label: 'Info', icon: Info },
];

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('map');

  const renderScreen = () => {
    switch (activeScreen) {
      case 'map':
        return <MapScreen />;
      case 'roads':
        return <RoadsScreen />;
      case 'report':
        return <ReportScreen />;
      case 'info':
        return <InfoScreen />;
      default:
        return <MapScreen />;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-ora-white max-w-md mx-auto border-x border-gray-200">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-ora-blue rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">O</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-ora-blue" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Ora
              </h1>
              <p className="text-xs text-gray-500">Disaster Resilience</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-ora-green rounded-full"></div>
            <span className="text-xs text-gray-600">Online</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 px-2 py-2">
        <div className="flex justify-around">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => setActiveScreen(item.id)}
                className={`flex flex-col items-center justify-center py-2 px-3 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? item.id === 'report'
                      ? 'bg-ora-green text-white'
                      : 'bg-ora-blue text-white'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className={`w-5 h-5 mb-1 ${
                  item.id === 'report' ? 'w-6 h-6' : 'w-5 h-5'
                }`} />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}