
  # Ora Disaster Resilience PWA

  This is a code bundle for Ora Disaster Resilience PWA. The original project is available at https://www.figma.com/design/mUgsGyQIp7io5KdZjmdd1O/Ora-Disaster-Resilience-PWA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  